/**
 * map.js - Module vẽ bản đồ SVG Việt Nam
 * Chịu trách nhiệm render nodes (tỉnh thành) và edges (đường nối)
 * trên SVG canvas, xử lý sự kiện click và tooltip.
 */

const VietnamMap = (() => {
    // ---- Configuration ----
    const CONFIG = {
        minLat: 8.5,
        maxLat: 23.0,
        minLng: 102.0,
        maxLng: 110.5,
        svgWidth: 700,
        svgHeight: 900,
        padding: 50,
        nodeRadius: 8,
        labelOffset: 16
    };

    let mapBounds = {
        minLat: CONFIG.minLat,
        maxLat: CONFIG.maxLat,
        minLng: CONFIG.minLng,
        maxLng: CONFIG.maxLng
    };

    // ---- State ----
    let nodes = [];
    let edges = [];
    let nodePositions = {};  // {cityName: {x, y}}
    let svgElement = null;
    let edgesLayer = null;
    let nodesLayer = null;
    let pathLayer = null;
    let onNodeClick = null;
    let onEdgeClick = null;
    let showLabels = false;
    let currentZoom = 1;
    let panX = 0, panY = 0;

    /**
     * Chuyển đổi tọa độ GPS sang tọa độ SVG.
     */
    function gpsToSvg(lat, lng) {
        const x = CONFIG.padding + 
            (lng - mapBounds.minLng) / (mapBounds.maxLng - mapBounds.minLng) * 
            (CONFIG.svgWidth - 2 * CONFIG.padding);
        const y = CONFIG.padding + 
            (mapBounds.maxLat - lat) / (mapBounds.maxLat - mapBounds.minLat) * 
            (CONFIG.svgHeight - 2 * CONFIG.padding);
        return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 };
    }

    /**
     * Nới các node quá sát nhau nhưng vẫn giữ dáng bản đồ tổng thể.
     */
    function relaxNodePositions() {
        const cityNames = Object.keys(nodePositions);
        if (cityNames.length < 2) return;

        const anchors = {};
        cityNames.forEach(cityName => {
            anchors[cityName] = { ...nodePositions[cityName] };
        });

        const minDistance = 34;
        const iterations = 18;

        for (let step = 0; step < iterations; step += 1) {
            cityNames.forEach(cityName => {
                const current = nodePositions[cityName];
                const anchor = anchors[cityName];

                // Spring back to original GPS projection so the map shape remains recognizable.
                current.x += (anchor.x - current.x) * 0.08;
                current.y += (anchor.y - current.y) * 0.08;
            });

            for (let i = 0; i < cityNames.length; i += 1) {
                for (let j = i + 1; j < cityNames.length; j += 1) {
                    const a = nodePositions[cityNames[i]];
                    const b = nodePositions[cityNames[j]];
                    const dx = b.x - a.x;
                    const dy = b.y - a.y;
                    const distance = Math.hypot(dx, dy) || 0.001;

                    if (distance >= minDistance) continue;

                    const overlap = (minDistance - distance) / 2;
                    const nx = dx / distance;
                    const ny = dy / distance;

                    // Push a bit more on the x axis because the current clutter is mostly horizontal.
                    const pushX = nx * overlap * 1.18;
                    const pushY = ny * overlap * 0.92;

                    a.x -= pushX;
                    a.y -= pushY;
                    b.x += pushX;
                    b.y += pushY;
                }
            }
        }

        cityNames.forEach(cityName => {
            const pos = nodePositions[cityName];
            pos.x = Math.max(CONFIG.padding - 10, Math.min(CONFIG.svgWidth - CONFIG.padding + 10, pos.x));
            pos.y = Math.max(CONFIG.padding - 10, Math.min(CONFIG.svgHeight - CONFIG.padding + 10, pos.y));
        });
    }

    /**
     * Tính bounds động theo dữ liệu hiện có để hiển thị cả đảo xa bờ.
     */
    function updateMapBounds() {
        if (!nodes.length) {
            mapBounds = {
                minLat: CONFIG.minLat,
                maxLat: CONFIG.maxLat,
                minLng: CONFIG.minLng,
                maxLng: CONFIG.maxLng
            };
            return;
        }

        const latitudes = nodes.map(node => node.lat);
        const longitudes = nodes.map(node => node.lng);
        const minLat = Math.min(...latitudes);
        const maxLat = Math.max(...latitudes);
        const minLng = Math.min(...longitudes);
        const maxLng = Math.max(...longitudes);
        const latPadding = Math.max(0.9, (maxLat - minLat) * 0.08);
        const lngPadding = Math.max(1.0, (maxLng - minLng) * 0.1);

        mapBounds = {
            minLat: minLat - latPadding,
            maxLat: maxLat + latPadding,
            minLng: minLng - lngPadding,
            maxLng: maxLng + lngPadding
        };
    }

    /**
     * Khởi tạo bản đồ.
     */
    function init(graphData, nodeClickHandler, edgeClickHandler) {
        nodes = graphData.nodes || [];
        edges = graphData.edges || [];
        nodePositions = {};
        onNodeClick = nodeClickHandler;
        onEdgeClick = edgeClickHandler;

        svgElement = document.getElementById('vietnam-map');
        edgesLayer = document.getElementById('edges-layer');
        nodesLayer = document.getElementById('nodes-layer');
        pathLayer = document.getElementById('path-layer');

        updateMapBounds();

        // Tính vị trí SVG cho mỗi node
        nodes.forEach(node => {
            nodePositions[node.name] = gpsToSvg(node.lat, node.lng);
        });

        relaxNodePositions();

        // Vẽ ranh giới bản đồ
        renderBoundary();

        renderEdges();
        renderNodes();
        setupZoom();
    }

    /**
     * Vẽ ảnh nền bản đồ Việt Nam.
     */
    function renderBoundary() {
        const boundaryLayer = document.getElementById('boundary-layer');
        if (!boundaryLayer) return;

        boundaryLayer.innerHTML = '';
    }

    /**
     * Vẽ các cạnh (đường nối giữa tỉnh thành).
     */
    function renderEdges() {
        edgesLayer.innerHTML = '';

        edges.forEach((edge, index) => {
            const from = nodePositions[edge.from];
            const to = nodePositions[edge.to];
            if (!from || !to) return;

            // Đường nối chính (hiển thị)
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', from.x);
            line.setAttribute('y1', from.y);
            line.setAttribute('x2', to.x);
            line.setAttribute('y2', to.y);
            line.setAttribute('class', `edge-line ${edge.blocked ? 'blocked' : ''}`);
            line.setAttribute('data-from', edge.from);
            line.setAttribute('data-to', edge.to);
            line.setAttribute('data-index', index);
            line.setAttribute('data-distance', edge.distance);
            edgesLayer.appendChild(line);

            // Đường nối phụ (trong suốt, to bản) để dễ bấm trúng
            const clickLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            clickLine.setAttribute('x1', from.x);
            clickLine.setAttribute('y1', from.y);
            clickLine.setAttribute('x2', to.x);
            clickLine.setAttribute('y2', to.y);
            clickLine.setAttribute('stroke', 'transparent');
            clickLine.setAttribute('stroke-width', '16');
            clickLine.setAttribute('cursor', 'pointer');

            // Hiệu ứng hover gián tiếp
            clickLine.addEventListener('mouseenter', () => {
                line.classList.add('hover-highlight');
            });
            clickLine.addEventListener('mouseleave', () => {
                line.classList.remove('hover-highlight');
            });

            // Click handler cho edge
            clickLine.addEventListener('click', (e) => {
                e.stopPropagation();
                if (onEdgeClick) {
                    onEdgeClick(edge.from, edge.to, index, edge.distance);
                }
            });

            edgesLayer.appendChild(clickLine);

            // Label khoảng cách
            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;

            const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            label.setAttribute('x', midX);
            label.setAttribute('y', midY - 5);
            label.setAttribute('class', `edge-label ${showLabels ? 'show' : ''}`);
            label.setAttribute('data-index', index);
            label.textContent = `${edge.distance}km`;
            edgesLayer.appendChild(label);

            // Block icon nếu bị chặn
            if (edge.blocked) {
                const blockIcon = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                blockIcon.setAttribute('x', midX);
                blockIcon.setAttribute('y', midY);
                blockIcon.setAttribute('class', 'edge-block-icon');
                blockIcon.setAttribute('data-block-index', index);
                blockIcon.textContent = '✕';
                edgesLayer.appendChild(blockIcon);
            }
        });
    }

    /**
     * Vẽ các node (tỉnh thành).
     */
    function renderNodes() {
        nodesLayer.innerHTML = '';
        const tooltip = document.getElementById('map-tooltip');
        const tooltipCity = document.getElementById('tooltip-city');
        const tooltipCoords = document.getElementById('tooltip-coords');

        nodes.forEach(node => {
            const pos = nodePositions[node.name];
            if (!pos) return;

            const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
            group.setAttribute('class', 'city-node');
            group.setAttribute('data-city', node.name);
            group.setAttribute('data-type', node.type || 'province');

            // Node circle
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', pos.x);
            circle.setAttribute('cy', pos.y);
            circle.setAttribute('r', CONFIG.nodeRadius);
            circle.setAttribute('class', `city-circle ${node.type === 'special_zone' ? 'special-zone' : ''}`);
            circle.setAttribute('data-city', node.name);

            // Node label
            const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            label.setAttribute('x', pos.x);
            label.setAttribute('y', pos.y + (node.type === 'special_zone' ? CONFIG.labelOffset - 6 : CONFIG.labelOffset));
            label.setAttribute('class', 'city-label');
            label.textContent = node.name;

            group.appendChild(circle);
            group.appendChild(label);

            // Hover tooltip
            group.addEventListener('mouseenter', (e) => {
                const rect = document.getElementById('map-container').getBoundingClientRect();
                const svgRect = svgElement.getBoundingClientRect();
                const scaleX = svgRect.width / CONFIG.svgWidth;
                const scaleY = svgRect.height / CONFIG.svgHeight;

                tooltipCity.textContent = node.name;
                tooltipCoords.textContent = `${node.lat.toFixed(4)}°N, ${node.lng.toFixed(4)}°E`;

                const tipX = svgRect.left - rect.left + pos.x * scaleX + 15;
                const tipY = svgRect.top - rect.top + pos.y * scaleY - 10;

                tooltip.style.left = `${tipX}px`;
                tooltip.style.top = `${tipY}px`;
                tooltip.classList.add('visible');
            });

            group.addEventListener('mouseleave', () => {
                tooltip.classList.remove('visible');
            });

            // Click handler
            group.addEventListener('click', (e) => {
                e.stopPropagation();
                if (onNodeClick) {
                    onNodeClick(node.name);
                }
            });

            nodesLayer.appendChild(group);
        });
    }

    /**
     * Cập nhật trạng thái visual cho node.
     */
    function setNodeState(cityName, state) {
        const circle = nodesLayer.querySelector(`circle[data-city="${cityName}"]`);
        if (!circle) return;

        // Reset classes
        circle.classList.remove('start', 'end', 'visited', 'frontier', 'current', 'in-path', 'animating');

        if (state) {
            circle.classList.add(state);
            if (state === 'current' || state === 'visited' || state === 'frontier') {
                circle.classList.add('animating');
                setTimeout(() => circle.classList.remove('animating'), 400);
            }
        }

        // Update label class
        const group = nodesLayer.querySelector(`g[data-city="${cityName}"]`);
        if (group) {
            const label = group.querySelector('.city-label');
            if (label) {
                label.classList.remove('start-label', 'end-label');
                if (state === 'start') label.classList.add('start-label');
                if (state === 'end') label.classList.add('end-label');
            }

            // Add role icon for start/end
            const existingIcon = group.querySelector('.city-role-icon');
            if (existingIcon) existingIcon.remove();

            if (state === 'start' || state === 'end') {
                const pos = nodePositions[cityName];
                const icon = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                icon.setAttribute('x', pos.x);
                icon.setAttribute('y', pos.y);
                icon.setAttribute('class', 'city-role-icon');
                icon.textContent = state === 'start' ? 'S' : 'E';
                group.appendChild(icon);
            }
        }
    }

    /**
     * Cập nhật trạng thái edge.
     */
    function setEdgeState(fromCity, toCity, state) {
        const edgeLines = edgesLayer.querySelectorAll('.edge-line');
        edgeLines.forEach(line => {
            const f = line.getAttribute('data-from');
            const t = line.getAttribute('data-to');
            if ((f === fromCity && t === toCity) || (f === toCity && t === fromCity)) {
                line.classList.remove('in-path', 'exploring');
                if (state) line.classList.add(state);
            }
        });
    }

    /**
     * Toggle chướng ngại vật trên edge.
     */
    function toggleEdgeBlock(fromCity, toCity, blocked) {
        const index = edges.findIndex(e =>
            (e.from === fromCity && e.to === toCity) ||
            (e.from === toCity && e.to === fromCity)
        );

        if (index >= 0) {
            edges[index].blocked = blocked;
            renderEdges();
        }
    }

    /**
     * Vẽ đường đi cuối cùng.
     */
    function drawPath(path) {
        pathLayer.innerHTML = '';

        if (!path || path.length < 2) return;

        let pathData = '';
        path.forEach((city, i) => {
            const pos = nodePositions[city];
            if (pos) {
                pathData += (i === 0 ? 'M' : 'L') + ` ${pos.x} ${pos.y} `;
            }
        });

        const pathElement = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        pathElement.setAttribute('d', pathData);
        pathElement.setAttribute('class', 'path-line');
        pathElement.setAttribute('stroke', 'url(#pathGradient)');

        // Tính tổng chiều dài path để set animation
        pathLayer.appendChild(pathElement);
        const totalLength = pathElement.getTotalLength();
        pathElement.style.strokeDasharray = totalLength;
        pathElement.style.strokeDashoffset = totalLength;
        pathElement.style.animation = `drawPath ${Math.min(totalLength / 300, 3)}s ease forwards`;
    }

    /**
     * Xóa đường đi.
     */
    function clearPath() {
        pathLayer.innerHTML = '';
    }

    /**
     * Reset tất cả trạng thái visual.
     */
    function resetAllStates() {
        nodesLayer.querySelectorAll('.city-circle').forEach(circle => {
            circle.classList.remove('start', 'end', 'visited', 'frontier', 'current', 'in-path', 'animating');
        });
        nodesLayer.querySelectorAll('.city-label').forEach(label => {
            label.classList.remove('start-label', 'end-label');
        });
        nodesLayer.querySelectorAll('.city-role-icon').forEach(icon => icon.remove());

        edgesLayer.querySelectorAll('.edge-line').forEach(line => {
            line.classList.remove('in-path', 'exploring');
        });

        clearPath();
    }

    /**
     * Toggle hiển thị labels khoảng cách.
     */
    function toggleDistanceLabels() {
        showLabels = !showLabels;
        edgesLayer.querySelectorAll('.edge-label').forEach(label => {
            label.classList.toggle('show', showLabels);
        });
        return showLabels;
    }

    /**
     * Setup zoom & pan.
     */
    function setupZoom() {
        const container = document.getElementById('map-container');

        document.getElementById('btn-zoom-in').addEventListener('click', () => {
            currentZoom = Math.min(currentZoom + 0.2, 3);
            applyZoom();
        });

        document.getElementById('btn-zoom-out').addEventListener('click', () => {
            currentZoom = Math.max(currentZoom - 0.2, 0.5);
            applyZoom();
        });

        document.getElementById('btn-zoom-reset').addEventListener('click', () => {
            currentZoom = 1;
            panX = 0;
            panY = 0;
            applyZoom();
        });

        // Mouse wheel zoom
        container.addEventListener('wheel', (e) => {
            e.preventDefault();
            const delta = e.deltaY > 0 ? -0.1 : 0.1;
            currentZoom = Math.min(Math.max(currentZoom + delta, 0.5), 3);
            applyZoom();
        });
    }

    function applyZoom() {
        const boundaryLayer = document.getElementById('boundary-layer');
        const allLayers = [boundaryLayer, edgesLayer, nodesLayer, pathLayer].filter(Boolean);
        allLayers.forEach(layer => {
            layer.setAttribute('transform', 
                `translate(${panX}, ${panY}) scale(${currentZoom})`
            );
        });
    }

    /**
     * Lấy danh sách tên tỉnh thành.
     */
    function getCityNames() {
        return nodes.map(n => n.name);
    }

    /**
     * Lấy trạng thái edges (blocked/unblocked).
     */
    function getBlockedEdges() {
        return edges.filter(e => e.blocked).map(e => [e.from, e.to]);
    }

    /**
     * Lấy vị trí SVG của một tỉnh thành.
     */
    function getNodePosition(cityName) {
        return nodePositions[cityName];
    }

    /**
     * Cập nhật hiển thị khoảng cách của một cạnh trên bản đồ
     */
    function updateEdgeDistanceLabel(city1, city2, newDistance) {
        // Cập nhật trong data
        const edge = edges.find(e => 
            (e.from === city1 && e.to === city2) || 
            (e.from === city2 && e.to === city1)
        );
        if (edge) {
            edge.distance = newDistance;
        }

        // Cập nhật giao diện (DOM)
        const line = document.querySelector(`.edge-line[data-from="${city1}"][data-to="${city2}"]`) ||
                     document.querySelector(`.edge-line[data-from="${city2}"][data-to="${city1}"]`);
        
        if (line) {
            line.setAttribute('data-distance', newDistance);
            const index = line.getAttribute('data-index');
            const label = document.querySelector(`text.edge-label[data-index="${index}"]`);
            if (label) {
                label.textContent = `${newDistance}km`;
            }
        }
    }

    // Public API
    return {
        init,
        setNodeState,
        setEdgeState,
        toggleEdgeBlock,
        drawPath,
        clearPath,
        resetAllStates,
        toggleDistanceLabels,
        getCityNames,
        getBlockedEdges,
        getNodePosition,
        renderEdges,
        updateEdgeDistanceLabel
    };
})();
