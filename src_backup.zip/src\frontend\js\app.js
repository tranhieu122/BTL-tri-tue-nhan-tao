/**
 * app.js - Module chính điều phối toàn bộ ứng dụng
 * Quản lý state, xử lý events, và kết nối các module.
 */

const App = (() => {
    // ---- Application State ----
    const state = {
        startCity: null,
        endCity: null,
        mode: 'select',      // 'select' | 'obstacle' | 'weight'
        isStepMode: false,
        isRunning: false,
        graphLoaded: false
    };

    /**
     * Khởi tạo ứng dụng.
     */
    async function init() {
        showToast('Đang kết nối tới server...', 'info');

        // Kiểm tra kết nối API
        const connected = await AlgorithmsAPI.checkConnection();
        updateConnectionStatus(connected);

        if (!connected) {
            showToast('⚠️ Không kết nối được server. Hãy chạy: python app.py', 'error');
            return;
        }

        try {
            // Lấy dữ liệu đồ thị
            const graphData = await AlgorithmsAPI.fetchGraph();

            // Khởi tạo bản đồ
            VietnamMap.init(graphData, handleNodeClick, handleEdgeClick);

            // Populate dropdowns
            populateCitySelects(graphData.nodes);

            // Cập nhật badge counts
            document.getElementById('city-count').textContent = graphData.nodes.length;
            document.getElementById('edge-count').textContent = graphData.edges.length;

            state.graphLoaded = true;
            showToast('✅ Đã tải bản đồ Việt Nam thành công!', 'success');

        } catch (error) {
            showToast(`❌ Lỗi tải dữ liệu: ${error.message}`, 'error');
        }

        // Setup event listeners
        setupEventListeners();
    }

    /**
     * Setup tất cả event listeners.
     */
    function setupEventListeners() {
        // ---- Toolbar Buttons ----
        document.getElementById('btn-select-mode').addEventListener('click', () => setMode('select'));
        document.getElementById('btn-obstacle-mode').addEventListener('click', () => setMode('obstacle'));
        document.getElementById('btn-weight-mode').addEventListener('click', () => setMode('weight'));
        document.getElementById('btn-clear-obstacles').addEventListener('click', clearObstacles);
        document.getElementById('btn-reset-all').addEventListener('click', resetAll);
        document.getElementById('btn-toggle-labels').addEventListener('click', () => {
            const showing = VietnamMap.toggleDistanceLabels();
            showToast(showing ? '📏 Hiện khoảng cách' : '📏 Ẩn khoảng cách', 'info');
        });

        // ---- Algorithm Controls ----
        document.getElementById('btn-find-path').addEventListener('click', findPath);
        document.getElementById('btn-step-mode').addEventListener('click', toggleStepMode);

        // ---- Playback Controls ----
        document.getElementById('btn-prev-step').addEventListener('click', () => Visualization.prevStep());
        document.getElementById('btn-play-pause').addEventListener('click', () => Visualization.togglePlay());
        document.getElementById('btn-next-step').addEventListener('click', () => Visualization.nextStep());

        // ---- Speed Slider ----
        const speedSlider = document.getElementById('speed-slider');
        const speedValue = document.getElementById('speed-value');
        speedSlider.addEventListener('input', (e) => {
            const speed = parseInt(e.target.value);
            speedValue.textContent = `${speed}ms`;
            Visualization.setSpeed(speed);
        });

        // ---- City Selects ----
        document.getElementById('start-select').addEventListener('change', (e) => {
            if (e.target.value) setStartCity(e.target.value);
        });
        document.getElementById('end-select').addEventListener('change', (e) => {
            if (e.target.value) setEndCity(e.target.value);
        });

        // ---- Compare ----
        document.getElementById('btn-compare').addEventListener('click', compareAll);
        document.getElementById('btn-close-compare').addEventListener('click', () => Comparison.hide());

        // ---- Window resize ----
        window.addEventListener('resize', () => {
            if (Comparison.getData()) {
                Comparison.renderChart();
            }
        });
    }

    /**
     * Xử lý click vào node trên bản đồ.
     */
    function handleNodeClick(cityName) {
        if (state.mode === 'obstacle') return;

        if (!state.startCity) {
            setStartCity(cityName);
        } else if (!state.endCity && cityName !== state.startCity) {
            setEndCity(cityName);
        } else {
            // Reset và chọn lại
            clearSelection();
            setStartCity(cityName);
        }
    }

    /**
     * Xử lý click vào edge trên bản đồ.
     */
    async function handleEdgeClick(fromCity, toCity, index, currentDistance) {
        if (state.mode === 'obstacle') {
            // Toggle block
            const currentEdges = VietnamMap.getBlockedEdges();
            const isBlocked = currentEdges.some(
                e => (e[0] === fromCity && e[1] === toCity) || (e[0] === toCity && e[1] === fromCity)
            );

            VietnamMap.toggleEdgeBlock(fromCity, toCity, !isBlocked);

            if (!isBlocked) {
                showToast(`🚧 Đã chặn: ${fromCity} ↔ ${toCity}`, 'info');
            } else {
                showToast(`✅ Đã mở: ${fromCity} ↔ ${toCity}`, 'success');
            }
        } else if (state.mode === 'weight') {
            const input = prompt(`Nhập khoảng cách mới (km) cho tuyến đường ${fromCity} - ${toCity}:\n(Hiện tại: ${currentDistance}km)`, currentDistance);
            
            if (input === null) return; // Bị hủy
            
            const newWeight = parseFloat(input);
            if (isNaN(newWeight) || newWeight <= 0) {
                showToast('⚠️ Khoảng cách phải là một số hợp lệ lớn hơn 0', 'error');
                return;
            }

            try {
                const res = await AlgorithmsAPI.updateEdgeWeight(fromCity, toCity, newWeight);
                VietnamMap.updateEdgeDistanceLabel(fromCity, toCity, newWeight);
                showToast(`✅ ${res.message}`, 'success');
            } catch (error) {
                showToast(`❌ Lỗi cập nhật: ${error.message}`, 'error');
            }
        }
    }

    /**
     * Set điểm xuất phát.
     */
    function setStartCity(cityName) {
        if (state.startCity) {
            VietnamMap.setNodeState(state.startCity, null);
        }
        state.startCity = cityName;
        VietnamMap.setNodeState(cityName, 'start');
        document.getElementById('start-select').value = cityName;
        updateToolbarStatus();
        updateButtons();
        showToast(`📍 Xuất phát: ${cityName}`, 'info');
    }

    /**
     * Set điểm đích.
     */
    function setEndCity(cityName) {
        if (state.endCity) {
            VietnamMap.setNodeState(state.endCity, null);
        }
        state.endCity = cityName;
        VietnamMap.setNodeState(cityName, 'end');
        document.getElementById('end-select').value = cityName;
        updateToolbarStatus();
        updateButtons();
        showToast(`🎯 Đích: ${cityName}`, 'info');
    }

    /**
     * Xóa selection.
     */
    function clearSelection() {
        if (state.startCity) VietnamMap.setNodeState(state.startCity, null);
        if (state.endCity) VietnamMap.setNodeState(state.endCity, null);
        state.startCity = null;
        state.endCity = null;
        document.getElementById('start-select').value = '';
        document.getElementById('end-select').value = '';
        updateToolbarStatus();
        updateButtons();
    }

    /**
     * Set chế độ tương tác.
     */
    function setMode(mode) {
        state.mode = mode;
        document.getElementById('btn-select-mode').classList.toggle('active', mode === 'select');
        document.getElementById('btn-obstacle-mode').classList.toggle('active', mode === 'obstacle');
        document.getElementById('btn-weight-mode').classList.toggle('active', mode === 'weight');
        updateToolbarStatus();
    }

    /**
     * Toggle chế độ step-by-step.
     */
    function toggleStepMode() {
        state.isStepMode = !state.isStepMode;
        const btn = document.getElementById('btn-step-mode');
        btn.classList.toggle('active', state.isStepMode);
        btn.innerHTML = state.isStepMode ? '👣 Từng bước ✓' : '👣 Từng bước';
    }

    /**
     * Tìm đường - gọi API và hiển thị kết quả.
     */
    async function findPath() {
        if (!state.startCity || !state.endCity) {
            showToast('⚠️ Hãy chọn điểm xuất phát và điểm đích!', 'error');
            return;
        }

        const algorithm = document.getElementById('algorithm-select').value;
        const blockedEdges = VietnamMap.getBlockedEdges();

        state.isRunning = true;
        updateButtons();

        // Reset visualization
        Visualization.reset();
        VietnamMap.resetAllStates();
        VietnamMap.setNodeState(state.startCity, 'start');
        VietnamMap.setNodeState(state.endCity, 'end');

        showToast(`🔍 Đang tìm đường bằng ${getAlgoDisplayName(algorithm)}...`, 'info');

        try {
            const result = await AlgorithmsAPI.findPath(
                state.startCity, state.endCity, algorithm, blockedEdges
            );

            if (result.path && result.path.length > 0) {
                // Cập nhật statistics
                updateStats(result);

                // Khởi tạo visualization
                const totalSteps = Visualization.init(result, {
                    onStepUpdate: (step, index, total) => {
                        document.getElementById('step-num').textContent = index + 1;
                        document.getElementById('step-current').textContent = step.current;
                        document.getElementById('step-cost').textContent = step.current_cost;
                    },
                    onComplete: (path) => {
                        showToast(`✅ Tìm thấy đường đi! ${result.cost} km, ${result.explored_count} node duyệt`, 'success');
                    }
                });

                if (state.isStepMode) {
                    // Chế độ từng bước - chờ user click
                    showToast(`👣 Chế độ từng bước: ${totalSteps} bước. Dùng nút điều khiển.`, 'info');
                } else {
                    // Chạy tự động
                    Visualization.play();
                }
            } else {
                showToast('❌ Không tìm được đường đi! Có thể do chướng ngại vật.', 'error');
                updateStats({ cost: -1, time_ms: result.time_ms, explored_count: result.explored_count, exploration_steps: result.exploration_steps });
            }

        } catch (error) {
            showToast(`❌ Lỗi: ${error.message}`, 'error');
        }

        state.isRunning = false;
        updateButtons();
    }

    /**
     * So sánh tất cả thuật toán.
     */
    async function compareAll() {
        if (!state.startCity || !state.endCity) {
            showToast('⚠️ Hãy chọn điểm xuất phát và điểm đích!', 'error');
            return;
        }

        const blockedEdges = VietnamMap.getBlockedEdges();

        showToast('📊 Đang so sánh 6 thuật toán...', 'info');

        try {
            const data = await AlgorithmsAPI.compareAlgorithms(
                state.startCity, state.endCity, blockedEdges
            );

            Comparison.show(data);
            showToast('✅ So sánh hoàn tất!', 'success');

        } catch (error) {
            showToast(`❌ Lỗi so sánh: ${error.message}`, 'error');
        }
    }

    /**
     * Xóa tất cả chướng ngại vật.
     */
    function clearObstacles() {
        // Re-fetch graph data để reset edges
        AlgorithmsAPI.fetchGraph().then(graphData => {
            graphData.edges.forEach(edge => {
                if (edge.blocked) {
                    VietnamMap.toggleEdgeBlock(edge.from, edge.to, false);
                }
            });
            VietnamMap.renderEdges();
            showToast('🗑️ Đã xóa tất cả chướng ngại vật', 'success');
        }).catch(() => {
            showToast('Đã xóa chướng ngại vật cục bộ', 'info');
        });
    }

    /**
     * Reset toàn bộ ứng dụng.
     */
    function resetAll() {
        Visualization.reset();
        clearSelection();
        Comparison.hide();
        resetStats();
        state.isStepMode = false;
        document.getElementById('btn-step-mode').classList.remove('active');
        document.getElementById('btn-step-mode').innerHTML = '👣 Từng bước';
        document.getElementById('step-info').style.display = 'none';
        showToast('↺ Đã reset tất cả', 'info');
    }

    /**
     * Cập nhật statistics UI.
     */
    function updateStats(result) {
        const animateStat = (id, value) => {
            const el = document.getElementById(id);
            el.textContent = value;
            el.classList.add('updating');
            setTimeout(() => el.classList.remove('updating'), 300);
        };

        animateStat('stat-distance', result.cost > 0 ? result.cost : '∞');
        animateStat('stat-time', result.time_ms ? result.time_ms.toFixed(4) : '--');
        animateStat('stat-explored', result.explored_count || '--');
        animateStat('stat-steps', result.exploration_steps ? result.exploration_steps.length : '--');
    }

    /**
     * Reset statistics.
     */
    function resetStats() {
        ['stat-distance', 'stat-time', 'stat-explored', 'stat-steps'].forEach(id => {
            document.getElementById(id).textContent = '--';
        });
    }

    /**
     * Populate city select dropdowns.
     */
    function populateCitySelects(cityNodes) {
        const startSelect = document.getElementById('start-select');
        const endSelect = document.getElementById('end-select');

        // Sắp xếp theo tên
        const sorted = [...cityNodes].sort((a, b) => a.name.localeCompare(b.name, 'vi'));

        sorted.forEach(city => {
            const opt1 = new Option(city.name, city.name);
            const opt2 = new Option(city.name, city.name);
            startSelect.appendChild(opt1);
            endSelect.appendChild(opt2);
        });
    }

    /**
     * Cập nhật trạng thái toolbar.
     */
    function updateToolbarStatus() {
        const status = document.getElementById('toolbar-status');
        if (state.mode === 'obstacle') {
            status.textContent = '🚧 Click vào đường để đặt/gỡ chướng ngại vật';
        } else if (!state.startCity) {
            status.textContent = '📍 Nhấn vào tỉnh thành để chọn điểm xuất phát';
        } else if (!state.endCity) {
            status.textContent = '🎯 Nhấn vào tỉnh thành để chọn điểm đích';
        } else {
            status.textContent = `✅ ${state.startCity} → ${state.endCity} | Nhấn "Tìm đường" để bắt đầu`;
        }
    }

    /**
     * Cập nhật trạng thái buttons.
     */
    function updateButtons() {
        const ready = state.startCity && state.endCity && !state.isRunning;
        document.getElementById('btn-find-path').disabled = !ready;
        document.getElementById('btn-compare').disabled = !ready;
    }

    /**
     * Cập nhật trạng thái kết nối.
     */
    function updateConnectionStatus(connected) {
        const badge = document.querySelector('.header-badge .dot');
        if (badge) {
            badge.style.background = connected ? 'var(--accent-emerald)' : 'var(--accent-rose)';
        }
        const label = badge?.nextElementSibling;
        if (label) {
            label.textContent = connected ? 'API Connected' : 'API Disconnected';
        }
    }

    /**
     * Lấy tên hiển thị cho thuật toán.
     */
    function getAlgoDisplayName(algo) {
        const names = {
            'astar': 'A* Search',
            'dijkstra': 'Dijkstra',
            'bfs': 'BFS',
            'dfs': 'DFS',
            'greedy': 'Greedy Best-First',
            'ucs': 'UCS'
        };
        return names[algo] || algo;
    }

    /**
     * Hiện toast notification.
     */
    function showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type} toast-enter`;

        const icons = {
            'success': '✅',
            'error': '❌',
            'info': 'ℹ️'
        };

        toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
        container.appendChild(toast);

        // Auto remove
        setTimeout(() => {
            toast.classList.remove('toast-enter');
            toast.classList.add('toast-exit');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // ---- Initialize on DOM ready ----
    document.addEventListener('DOMContentLoaded', init);

    // Public API (for debugging)
    return {
        getState: () => ({ ...state }),
        showToast
    };
})();
